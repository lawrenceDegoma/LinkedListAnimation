//
// Created by Lawrence Degoma on 5/22/24.
//

#ifndef LINKEDLISTANIMATION_NODE_H
#define LINKEDLISTANIMATION_NODE_H


class Node {
public:
    int data;
    Node* next;
    Node* prev;

    Node(int value);
};


#endif //LINKEDLISTANIMATION_NODE_H
