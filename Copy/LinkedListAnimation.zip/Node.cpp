//
// Created by Lawrence Degoma on 5/22/24.
//

#include "Node.h"

Node::Node(int value) : data(value), next(nullptr), prev(nullptr) {}